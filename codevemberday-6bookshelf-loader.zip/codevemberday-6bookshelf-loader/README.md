# #Codevember - Day 6 - Bookshelf loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/ikoshowa/pen/qOMvpy](https://codepen.io/ikoshowa/pen/qOMvpy).

A nice moving bookshelf animation done only with css animations.

From Dribbble : https://dribbble.com/shots/2332418-Book-shelf-Loader-Icon